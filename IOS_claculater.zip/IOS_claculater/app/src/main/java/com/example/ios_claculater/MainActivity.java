package com.example.ios_claculater;

import androidx.appcompat.app.AppCompatActivity;

import com.example.ios_claculater.calculatorMind;

import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    String num1 = "", num2 = ""; // represent the number1 and number2
    String operation = "";// represent the operation
    TextView tv;   //TextView to show the result
    int dotPerNum1 = 0, dotPerNum2 = 0;  //represent the number of dot(.) for number1 and number2

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = findViewById(R.id.result);
    }

    // OnPressed(View v) callback function get called when the user press any number also the .
    public void OnPressed(View v) {
        // int bottonID = v.getId();
        Button b = (Button) v; // cast v object to button to be able to use the button function like getText()
        String n = b.getText().toString();
        if (operation != "") {  //check if the use click any operation to decide which number will be enterd if there is operation we enter the second number else we enter the first
            if (n.equals(".")) { //check if user press dot
                if (dotPerNum2 > 0) //check if number2 has at least one dot if true we dont add another one
                    return;
                dotPerNum2++;
            }  //if not we increase the number of dot for number2
            num2 += n;
        } else {
            if (n.equals(".")) { //check if user press dot
                if (dotPerNum1 > 0) //check if number1 has at least one dot if true we dont add another one
                    return;
                dotPerNum1++;
            }  //if not we increase the number of dot for number1
            num1 += n;
        }
        tv.setText(num1 + operation + num2); //show the operation on the screen
    }

    // operation(View v) callback function get called when the user press any operation  + / - * %
    public void operation(View v) {
        if (num1.equals("")) //we cant enter operation while the first number is empty
            return;
        Button b = (Button) v;
        operation = b.getText().toString(); //set the operation
        tv.setText(num1 + operation + num2);
//        Log.i("main2", operation);
//        Log.i("number1", num1);
//        Log.i("number2", num2);
    }

    // Clear(View v) callback function get called when the user press AC button
    public void Clear(View v) {
        num2 = "";
        num1 = "";
        operation = "";
        dotPerNum1=0;
        dotPerNum2=0;
        tv.setText("0");
    }

    // Calculat(View v)callback function get called when the user press = button
    public void Calculat(View v) {
        if (num1.equals("") & num2.equals("")) //we cant calculate while any one of the numbers is empty
            return;
        float res = 0;  //represent the result
        calculatorMind module = new calculatorMind(num1, num2);
        if (operation.charAt(0) == '+')
            res = module.sum();
        else if (operation.charAt(0) == '-')
            res = module.sub();
        else if (operation.equals("*"))
            res = module.mul();
        else if (operation.charAt(0) == '/')
            res = module.div();
        else if (operation.charAt(0) == '%')
            res = (float) module.mod();
        tv.setText(num1 + operation + num2 + "=" + "\n" + res);
    }

    //ToggelNumber(View v) get called when the user press +/- button it's inverts the number sign
    public void ToggleNumber(View v) {
        if (num1.equals("")) //we cant use this function unless we have the first number
            return;
        float num;
        if (operation != "") { // we check the operation to decide if we will toggle the first or the second number if the opreation not empty we invert the second nuber else we invert the first one
            if (num2.equals("")) //handel if the user enter the first number and the operation but didt enter the second number
                return;
            num = Float.parseFloat(num2);
            num2 = String.valueOf(num *= -1);
            tv.setText(num1 + operation + num2);
            // Log.i("toggle number2 ", num2);
        } else {
            num = Float.parseFloat(num1);
            num1 = String.valueOf(num *= -1);
            tv.setText(num1 + operation + num2);
            //  Log.i("toggle number1 ", num1);
        }
    }
//
//    f
//
}
