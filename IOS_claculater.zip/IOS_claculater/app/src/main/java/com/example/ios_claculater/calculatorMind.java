package com.example.ios_claculater;

public class calculatorMind {
    float num1, num2;

    calculatorMind(String n, String n2) {
        this.num1 = Float.parseFloat(n);
        this.num2 = Float.parseFloat(n2);
    }

    public float sum() {
        return num1 + num2;
    }

    public float mul() {
        return num1 * num2;
    }

    public float sub() {
        return num1 - num2;
    }

    public float div() {
        return num1 / num2;
    }

    public int mod() {

        return (int) (num1) % (int) (num2);
    }
}
